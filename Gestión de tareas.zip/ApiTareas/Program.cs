using Microsoft.Data.SqlClient;

var builder = WebApplication.CreateBuilder(args);

// documentación
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// CORS abierto, ajusta en prod
builder.Services.AddCors(o =>
    o.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();

app.UseCors();

// Swagger UI solo si está habilitado
app.UseSwagger();
app.UseSwaggerUI();

// Cadena de conexión
string conexion =
    "Server=HENRYOCHOA\\SQLEXPRESS;Database=GestionTareas;User Id=sa;Password=Aswedfr36;TrustServerCertificate=True;";

// GET: /api/tareas/idProyecto
app.MapGet("/api/tareas/{idProyecto:int}", async (int idProyecto) =>
{
    using var conn = new SqlConnection(conexion);
    await conn.OpenAsync();

    using var cmd = new SqlCommand("SELECT * FROM gt.vwTareas WHERE IdProyecto=@id", conn);
    cmd.Parameters.AddWithValue("@id", idProyecto);

    using var reader = await cmd.ExecuteReaderAsync();
    var lista = new List<object>();
    while (await reader.ReadAsync())
    {
        lista.Add(new
        {
            IdTarea = reader["IdTarea"],
            Titulo = reader["Titulo"],
            Descripcion = reader["Descripcion"],
            Prioridad = reader["Prioridad"],
            Estado = reader["Estado"],
            VenceUtc = reader["VenceUtc"],
            Creador = reader["Creador"]
        });
    }
    return Results.Ok(lista);
})
.WithName("ListarTareas")
.WithOpenApi();

// POST: /api/tareas
app.MapPost("/api/tareas", async (NuevaTarea body) =>
{
    using var conn = new SqlConnection(conexion);
    await conn.OpenAsync();

    using var cmd = new SqlCommand(
        "EXEC gt.sp_Tareas_Crear @IdProyecto,@Titulo,@Descripcion,@Prioridad,@VenceUtc,@IdCreador", conn);

    cmd.Parameters.AddWithValue("@IdProyecto", body.IdProyecto);
    cmd.Parameters.AddWithValue("@Titulo", body.Titulo);
    cmd.Parameters.AddWithValue("@Descripcion", (object?)body.Descripcion ?? DBNull.Value);
    cmd.Parameters.AddWithValue("@Prioridad", body.Prioridad);
    cmd.Parameters.AddWithValue("@VenceUtc", body.VenceUtc.HasValue ? body.VenceUtc.Value : (object)DBNull.Value);
    cmd.Parameters.AddWithValue("@IdCreador", body.IdCreador);

    var id = (decimal?)await cmd.ExecuteScalarAsync();
    return Results.Created($"/api/tareas/{id}", new { IdTarea = id });
})
.WithName("CrearTarea")
.WithOpenApi();

// Forzado de puerto 5000
app.Run("http://localhost:5000");

// DTO del POST
public record NuevaTarea(int IdProyecto, string Titulo, string? Descripcion, byte Prioridad, DateTime? VenceUtc, int IdCreador);

